conjunto_cores = {"vermelho", "azul", "verde"}

conjunto_cores.add("branco")
conjunto_cores.add("vermelho")

conjunto_cores.remove("branco")

print(conjunto_cores)

# LISTAS
# TUPLAS
# DICIONARIOS
# CONJUNTOS