tuplas_cores = ("amarelo", "azul", "roxo")


for cor in tuplas_cores:
    print(cor)