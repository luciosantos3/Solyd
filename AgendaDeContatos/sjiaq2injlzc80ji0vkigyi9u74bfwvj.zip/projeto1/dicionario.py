pessoas = {
    "guilherme": 19,
    "maria": 17,
    "joão": 20,
}

for pessoa in pessoas:
    print(pessoas[pessoa])