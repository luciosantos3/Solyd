contador = 0

while contador < 10:
    print('Essa condição é verdadeira')
    contador = contador + 1