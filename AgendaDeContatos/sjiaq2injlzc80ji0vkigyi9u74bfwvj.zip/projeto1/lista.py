nome = "Guilherme"
idade = 19

minha_lista = ["azul", "amarelo", "verde", "vermelho", "roxo", "branco"]    # lista de cores

for letra in nome:
    print(letra)
    print("olá")

print("Sai do for")



# LISTAS - OK
# TUPLAS
# DICIONARIOS
# CONJUNTOS
