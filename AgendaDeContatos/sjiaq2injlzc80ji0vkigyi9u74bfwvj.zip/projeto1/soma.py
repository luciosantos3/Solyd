def soma(primeiro_numero, segundo_numero):
    resultado = primeiro_numero + segundo_numero
    print(resultado)


soma(1, 2)